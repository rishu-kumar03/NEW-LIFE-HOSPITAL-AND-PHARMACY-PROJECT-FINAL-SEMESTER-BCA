import { Payment } from "../models/paymentModel.js";


export const createPayment = async (req, res) => {
  const { name, address, phone, amount, cartItems } = req.body;

  if (!req.file || !req.file.path) {
    return res.status(400).json({ error: 'Payment proof is required.' });
  }

  try {
    const parsedCartItems = JSON.parse(cartItems);
    const newPayment = new Payment({
      name,
      address,
      phone,
      amount,
      cartItems: parsedCartItems,
      paymentProof: req.file.path, // Cloudinary URL
    });

    await newPayment.save();
    res.status(201).json({ message: 'Payment submitted successfully!' });
  } catch (error) {
    console.error(error);
    res.status(500).json({ error: 'Failed to process the payment.' });
  }
};

export const getAllPayments = async (req, res) => {
  try {
    const payments = await Payment.find().sort({ paymentDate: -1 });
    res.status(200).json(payments);
  } catch (error) {
    res.status(500).json({ error: 'Failed to retrieve payments.' });
  }
};
