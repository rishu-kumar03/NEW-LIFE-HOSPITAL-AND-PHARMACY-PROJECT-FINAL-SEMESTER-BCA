import { Medicine } from "../models/medicineModel.js";

// @desc Get all medicines
// @route GET /api/medicines
export const getMedicines = async (req, res) => {
  try {
    const medicines = await Medicine.find();
    res.status(200).json(medicines);
  } catch (error) {
    res.status(500).json({ message: "Error fetching medicines", error });
  }
};

// @desc Get a single medicine by ID
// @route GET /api/medicines/:id
export const getMedicineById = async (req, res) => {
  try {
    const medicine = await Medicine.findById(req.params.id);
    if (!medicine) return res.status(404).json({ message: "Medicine not found" });
    res.status(200).json(medicine);
  } catch (error) {
    res.status(500).json({ message: "Error fetching medicine", error });
  }
};

// @desc Add a new medicine or update stock if it exists
// @route POST /api/medicines
export const addMedicine = async (req, res) => {
  try {
    const { name, price, exp, stock, category } = req.body;

    if (!name || !price || !exp || !stock || !category) {
      return res.status(400).json({ message: "All fields are required" });
    }

    let existingMedicine = await Medicine.findOne({ name, category });

    if (existingMedicine) {
      existingMedicine.stock += Number(stock);
      existingMedicine.price = price; 
      existingMedicine.exp = exp;

      const updatedMedicine = await existingMedicine.save();
      return res.status(200).json({ message: "Stock updated successfully", updatedMedicine });
    }

    const newMedicine = new Medicine({ name, price, exp, stock, category });
    await newMedicine.save();
    
    res.status(201).json({ message: "Medicine added successfully", newMedicine });
  } catch (error) {
    console.error("Error adding medicine:", error);
    res.status(500).json({ message: "Error adding medicine", error: error.message });
  }
};

// Delete Medicine (DELETE)
export const deleteMedicine = async (req, res) => {
  try {
    console.log("Delete Request Received for ID:", req.params.id);

    const deletedMedicine = await Medicine.findByIdAndDelete(req.params.id);
    if (!deletedMedicine) {
      console.log("Medicine not found:", req.params.id);
      return res.status(404).json({ message: "Medicine not found" });
    }

    console.log("Medicine deleted:", deletedMedicine);
    res.status(200).json({ message: "Medicine deleted successfully" });
  } catch (error) {
    console.error("Error deleting medicine:", error);
    res.status(500).json({ message: "Error deleting medicine", error: error.message });
  }
};

// @desc Update a medicine by ID
// @route PUT /api/medicines/:id
export const updateMedicine = async (req, res) => {
  try {
    const updatedMedicine = await Medicine.findByIdAndUpdate(
      req.params.id,
      req.body,
      { new: true }
    );
    if (!updatedMedicine) return res.status(404).json({ message: "Medicine not found" });

    res.status(200).json({ message: "Medicine updated successfully", updatedMedicine });
  } catch (error) {
    res.status(500).json({ message: "Error updating medicine", error });
  }
};
