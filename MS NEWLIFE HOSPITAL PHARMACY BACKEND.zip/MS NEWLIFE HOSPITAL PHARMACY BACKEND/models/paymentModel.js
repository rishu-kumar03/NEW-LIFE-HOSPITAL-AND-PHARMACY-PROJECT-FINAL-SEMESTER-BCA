import mongoose from 'mongoose';

const paymentSchema = new mongoose.Schema({
  name: {
    type: String,
    required: true,
  },
  address: {
    type: String,
    required: true,
  },
  phone: {
    type: String,
    required: true,
  },
  paymentProof: {
    type: String, // URL or Path for the uploaded image
    required: true,
  },
  amount: {
    type: Number,
    required: true,
  },
  cartItems: { type: Array, required: true },
  paymentDate: {
    type: Date,
    default: Date.now,
  },
});

export const Payment = mongoose.model('Payment', paymentSchema);
