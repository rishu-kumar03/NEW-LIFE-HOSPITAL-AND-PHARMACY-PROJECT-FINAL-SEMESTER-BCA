import express from 'express';
import { createPayment, getAllPayments } from '../controllers/paymentController.js';
import { upload } from '../config/cloudinaryConfig.js'; // Cloudinary Config

const router = express.Router();

// Payment Routes
router.post('/create', upload.single('paymentProof'), createPayment);
router.get('/', getAllPayments);

export default router;
