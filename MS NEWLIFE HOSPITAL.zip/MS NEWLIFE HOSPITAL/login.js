document.addEventListener('DOMContentLoaded', () => {
    // Get Elements
    const loginForm = document.getElementById('loginForm');
    const inputUsername = document.getElementById('inputUsername');
    const inputPassword = document.getElementById('inputPassword');
    const errorMessage = document.getElementById('errorMessage');
    const successMessage = document.getElementById('successMessage');

    // Buttons for Login and Logout
    const loginButton = document.getElementById('loginButton');
    const logoutButton = document.getElementById('logoutButton');

    // Function to Check Login Status
    function checkLoginStatus() {
        const token = localStorage.getItem('authToken');

        // Check if loginButton and logoutButton exist before accessing style property
        if (loginButton && logoutButton) {
            if (token) {
                // User is Logged In
                loginButton.style.display = 'none';
                logoutButton.style.display = 'inline-block';
            } else {
                // User is Logged Out
                loginButton.style.display = 'inline-block';
                logoutButton.style.display = 'none';
            }
        } else {
            console.error("Login or Logout button not found in the DOM.");
        }
    }

    // Check Login Status on Page Load
    checkLoginStatus();

    // Login Form Submit Handler
    if (loginForm) {
        loginForm.addEventListener('submit', async (event) => {
            event.preventDefault();
            const email = inputUsername.value;
            const password = inputPassword.value;

            console.log("Attempting to log in with Email:", email);

            try {
                const response = await fetch('https://backend-pwa8.onrender.com/api/users/login', {
                    method: 'POST',
                    headers: {
                        'Content-Type': 'application/json',
                    },
                    body: JSON.stringify({ email, password }),
                });

                console.log("Response Status:", response.status);

                const data = await response.json();
                console.log("Server Response:", data);

                if (response.ok && data.status) {
                    // Store JWT token in localStorage
                    localStorage.setItem('authToken', data.token);
                    localStorage.setItem('isAdmin', data.isAdmin);

                    // Display success message and redirect
                    if (successMessage) {
                        successMessage.textContent = 'Login successful! Redirecting...';
                    }
                    if (errorMessage) {
                        errorMessage.textContent = '';  // Clear any previous errors
                    }
                    console.log("Login successful. Redirecting...");

                    // Toggle Buttons
                    if (loginButton && logoutButton) {
                        loginButton.style.display = 'none';
                        logoutButton.style.display = 'inline-block';
                    }

                    setTimeout(() => {
                        window.location.href = 'index.html';
                    }, 1500);
                } else {
                    if (errorMessage) {
                        errorMessage.textContent = data.message;
                    }
                    if (successMessage) {
                        successMessage.textContent = '';
                    }
                    console.log("Login failed:", data.message);
                }
            } catch (error) {
                console.error("Error during login request:", error);
                if (errorMessage) {
                    errorMessage.textContent = 'Network error. Please try again later.';
                }
            }
        });
    }

    // Login Button Click Handler (Redirect to Login Page)
    if (loginButton) {
        loginButton.addEventListener('click', () => {
            window.location.href = 'login.html';
        });
    }

    // Logout Button Click Handler
    if (logoutButton) {
        logoutButton.addEventListener('click', () => {
            console.log("Logging out...");
            localStorage.removeItem('authToken');
            localStorage.removeItem('isAdmin');
            
            // Check if successMessage element exists before accessing it
            if (successMessage) {
                successMessage.textContent = 'Logged out successfully!';
            }
            
            // Toggle Buttons
            if (loginButton && logoutButton) {
                logoutButton.style.display = 'none';
                loginButton.style.display = 'inline-block';
            }
            
            setTimeout(() => {
                window.location.href = 'login.html';
            }, 1000);
        });
    }
});
