document.addEventListener('DOMContentLoaded', () => {
    const galleryContainer = document.getElementById('galleryContainer');
    const uploadContainer = document.getElementById('uploadContainer');
    const uploadForm = document.getElementById('uploadForm');

    // Check if user is logged in
    const token = localStorage.getItem('authToken');
    if (token) {
        console.log("User is logged in. Displaying upload option.");
        uploadContainer.classList.remove('Abhinav-hidden');
    } else {
        console.log("User is not logged in. Hiding upload option.");
        uploadContainer.classList.add('Abhinav-hidden');
    }

    // Load Images from Backend
    const loadImages = async () => {
        try {
            const response = await fetch('https://backend-pwa8.onrender.com/api/images');
            if (!response.ok) {
                throw new Error(`HTTP error! Status: ${response.status}`);
            }

            const images = await response.json();
            console.log("Fetched Images:", images);

            // Clear existing images
            galleryContainer.innerHTML = '';

            // Check if images array is empty
            if (images.length === 0) {
                galleryContainer.innerHTML = '<p>No images available at the moment.</p>';
                return;
            }

            images.forEach(image => {
                // Create image container
                const imgElement = document.createElement('div');
                imgElement.classList.add('Abhinav-gallery-item');
                imgElement.innerHTML = `
                    <img src="${image.imageUrl}" alt="Gallery Image" class="Abhinav-gallery-img" style="width: 100%; max-width: 300px; border-radius: 10px; box-shadow: 0 4px 8px rgba(0, 0, 0, 0.2); margin: 10px;">
                `;

                // Add Delete Button (Only if logged in)
                if (token) {
                    const deleteBtn = document.createElement('button');
                    deleteBtn.classList.add('Abhinav-delete-btn');
                    deleteBtn.textContent = 'Delete';
                    deleteBtn.style.cssText = `
                        background-color: #f44336;
                        color: white;
                        padding: 5px 10px;
                        border: none;
                        border-radius: 5px;
                        cursor: pointer;
                        margin-top: 10px;
                    `;
                    deleteBtn.addEventListener('click', () => {
                        deleteImage(image._id);
                    });
                    imgElement.appendChild(deleteBtn);
                }

                galleryContainer.appendChild(imgElement);
            });
        } catch (error) {
            console.error("Error loading images:", error);
            galleryContainer.innerHTML = '<p>Error loading images. Please try again later.</p>';
        }
    };

    // Call loadImages to load images on page load
    loadImages();

    // Handle Image Upload
    uploadForm.addEventListener('submit', async (event) => {
        event.preventDefault();
        const fileInput = document.getElementById('imageFile');
        const formData = new FormData();
        formData.append('image', fileInput.files[0]);

        try {
            const response = await fetch('https://backend-pwa8.onrender.com/api/upload', {
                method: 'POST',
                headers: {
                    'Authorization': `Bearer ${token}`
                },
                body: formData
            });

            const data = await response.json();
            console.log("Upload Response:", data);

            if (response.ok) {
                alert("Image uploaded successfully!");
                loadImages();  // Reload images after successful upload
                fileInput.value = '';  // Clear the file input
            } else {
                alert(data.message);
            }
        } catch (error) {
            console.error("Error uploading image:", error);
            alert("Error uploading image. Please try again later.");
        }
    });

    // Delete Image Function
    const deleteImage = async (imageId) => {
        if (confirm("Are you sure you want to delete this image?")) {
            try {
                const response = await fetch(`https://backend-pwa8.onrender.com/api/images/${imageId}`, {
                    method: 'DELETE',
                    headers: {
                        'Authorization': `Bearer ${token}`
                    }
                });

                const data = await response.json();
                console.log("Delete Response:", data);

                if (response.ok) {
                    alert("Image deleted successfully!");
                    loadImages();  // Reload images after successful deletion
                } else {
                    alert("Failed to delete image. Please try again.");
                }
            } catch (error) {
                console.error("Error deleting image:", error);
                alert("Error deleting image. Please try again later.");
            }
        }
    };
});
