import React, { useContext } from "react";
import { AuthContext } from "../context/AuthContext"; // Import the AuthContext
import toast from "react-hot-toast";
const Logout = () => {
    const { logout } = useContext(AuthContext); // Get logout function from context

    const handleLogout = () => {
         logout(); // Call the logout function from context
        toast.success("Logged out successfully!");
    };

    return <button onClick={handleLogout}>Logout</button>;
};

export default Logout;
