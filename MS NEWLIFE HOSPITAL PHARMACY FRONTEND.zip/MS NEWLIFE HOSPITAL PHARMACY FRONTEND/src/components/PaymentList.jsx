import { useEffect, useState } from 'react';
import axios from 'axios';
import { Search, ChevronLeft, ChevronRight } from 'lucide-react';
const API_BASE_URL = import.meta.env.VITE_API_BASE_URL;
const PaymentList = () => {
  const [payments, setPayments] = useState([]);
  const [searchQuery, setSearchQuery] = useState('');
  const [currentPage, setCurrentPage] = useState(1);
  const itemsPerPage = 5;

  // Fetch Payments from API
  useEffect(() => {
    const fetchPayments = async () => {
      try {
        const response = await axios.get(`${API_BASE_URL}/api/payments`);
        setPayments(response.data);
      } catch (error) {
        console.error('Error fetching payments:', error);
      }
    };

    fetchPayments();
  }, []);

  // Filtered Payments for Search
  const filteredPayments = payments.filter((payment) =>
    payment.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
    payment.phone.includes(searchQuery)
  );

  // Pagination Logic
  const totalPages = Math.ceil(filteredPayments.length / itemsPerPage);
  const paginatedPayments = filteredPayments.slice(
    (currentPage - 1) * itemsPerPage,
    currentPage * itemsPerPage
  );

  const handlePageChange = (direction) => {
    if (direction === 'next' && currentPage < totalPages) {
      setCurrentPage(currentPage + 1);
    } else if (direction === 'prev' && currentPage > 1) {
      setCurrentPage(currentPage - 1);
    }
  };

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
      <div className="flex flex-col sm:flex-row justify-between items-center mb-6 gap-4">
        <h2 className="text-xl sm:text-2xl font-bold text-gray-800">Payment Records</h2>

        <div className="relative w-full sm:w-64">
          <input
            type="text"
            placeholder="Search by name or phone..."
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            className="border p-2 pl-8 rounded-md w-full"
          />
          <Search className="absolute left-2 top-2.5 text-gray-400 h-5 w-5" />
        </div>
      </div>

      {/* Payment Table */}
      <div className="bg-white rounded-lg shadow overflow-x-auto">
        <table className="min-w-full text-sm">
          <thead className="bg-gray-50">
            <tr>
              <th className="px-2 sm:px-4 py-3 text-left">Name</th>
              <th className="px-2 sm:px-4 py-3 text-left hidden sm:table-cell">Address</th>
              <th className="px-2 sm:px-4 py-3 text-left">Phone</th>
              <th className="px-2 sm:px-4 py-3 text-left">Amount</th>
              <th className="px-2 sm:px-4 py-3 text-left hidden sm:table-cell">Date</th>
              <th className="px-2 sm:px-4 py-3 text-left">Payment Proof</th>
              <th className="px-2 sm:px-4 py-3 text-left hidden sm:table-cell">Cart Items</th>
            </tr>
          </thead>
          <tbody>
            {paginatedPayments.map((payment) => (
              <tr key={payment._id} className="hover:bg-gray-50">
                <td className="px-2 sm:px-4 py-4">{payment.name}</td>
                <td className="px-2 sm:px-4 py-4 hidden sm:table-cell">{payment.address}</td>
                <td className="px-2 sm:px-4 py-4">{payment.phone}</td>
                <td className="px-2 sm:px-4 py-4">₹{payment.amount.toFixed(2)}</td>
                <td className="px-2 sm:px-4 py-4 hidden sm:table-cell">{new Date(payment.paymentDate).toLocaleDateString()}</td>
                <td className="px-2 sm:px-4 py-4">
                  {payment.paymentProof && (
                    <a
                      href={payment.paymentProof}
                      target="_blank"
                      rel="noopener noreferrer"
                      className="text-blue-600 hover:underline"
                    >
                      View Proof
                    </a>
                  )}
                </td>
                <td className="px-2 sm:px-4 py-4 hidden sm:table-cell">
                  <div className="space-y-2">
                    {payment.cartItems.map((item, index) => (
                      <div
                        key={index}
                        className="p-2 border border-gray-200 rounded-md"
                      >
                        <p className="font-medium">{item.name}</p>
                        <p className="text-sm text-gray-600">
                          Qty: {item.quantity} × ₹{item.price.toFixed(2)} = ₹
                          {(item.quantity * item.price).toFixed(2)}
                        </p>
                      </div>
                    ))}
                  </div>
                </td>
              </tr>
            ))}

            {paginatedPayments.length === 0 && (
              <tr>
                <td colSpan="7" className="text-center py-4 text-gray-500">
                  No payments found.
                </td>
              </tr>
            )}
          </tbody>
        </table>
      </div>

      {/* Pagination Controls */}
      <div className="flex flex-col sm:flex-row justify-center items-center mt-4 gap-4">
        <button
          onClick={() => handlePageChange('prev')}
          disabled={currentPage === 1}
          className={`px-4 py-2 rounded-md ${currentPage === 1 ? 'bg-gray-300' : 'bg-blue-600 text-white hover:bg-blue-700'}`}
        >
          <ChevronLeft className="h-5 w-5 inline-block" /> Prev
        </button>
        <span>
          Page {currentPage} of {totalPages}
        </span>
        <button
          onClick={() => handlePageChange('next')}
          disabled={currentPage === totalPages}
          className={`px-4 py-2 rounded-md ${currentPage === totalPages ? 'bg-gray-300' : 'bg-blue-600 text-white hover:bg-blue-700'}`}
        >
          Next <ChevronRight className="h-5 w-5 inline-block" />
        </button>
      </div>
    </div>
  );
};

export default PaymentList;