import { useState } from "react";
import { useNavigate } from 'react-router-dom';
import { Plus,  Edit, Trash, Search, ChevronLeft, ChevronRight } from "lucide-react";
import axios from "axios";
import { toast } from "react-hot-toast";
const API_BASE_URL = import.meta.env.VITE_API_BASE_URL;
const AdminPanel = ({ medicines }) => {

  const navigate = useNavigate();
  const [showForm, setShowForm] = useState(false);
  const [editingMedicine, setEditingMedicine] = useState(null);
  const [newMedicine, setNewMedicine] = useState({
    name: "",
    price: "",
    exp: "",
    stock: "",
    category: ""
  });

  const [searchQuery, setSearchQuery] = useState("");
  const [currentPage, setCurrentPage] = useState(1);
  const itemsPerPage = 5;

  const filteredMedicines = medicines.filter((medicine) =>
    medicine.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
    medicine.category.toLowerCase().includes(searchQuery.toLowerCase()) ||
    medicine.exp.includes(searchQuery)
  );

  const handleSubmit = async (e) => {
    e.preventDefault();

    const medicineData = {
      name: newMedicine.name?.trim(),
      price: Number(newMedicine.price),
      exp: newMedicine.exp,
      stock: Number(newMedicine.stock),
      category: newMedicine.category?.trim().toLowerCase()
    };

    try {
      if (editingMedicine) {
        const response = await axios.put(
          `${API_BASE_URL}/api/medicines/${editingMedicine._id || editingMedicine.id}`,
          medicineData
        );

        if (response.status === 200) {
          toast.success("Medicine updated successfully!");
          window.location.reload();
        } else {
          toast.error(response.data.message || "Update failed.");
        }
      } else {
        const response = await axios.post(
          `${API_BASE_URL}/api/medicines`,
          medicineData
        );

        if (response.status === 201) {
          toast.success("Medicine added successfully!");
          window.location.reload();
        } else {
          toast.error(response.data.message || "Failed to add medicine.");
        }
      }

      setShowForm(false);
      setEditingMedicine(null);
    } catch (error) {
      console.error("Error:", error);
      toast.error("Something went wrong!");
    }

    setNewMedicine({ name: "", price: "", exp: "", stock: "", category: "" });
  };

  const handleEdit = (medicine) => {
    setNewMedicine({ ...medicine });
    setEditingMedicine(medicine);
    setShowForm(true);
  };

  const handleAddMedicine = () => {
    setNewMedicine({ name: "", price: "", exp: "", stock: "", category: "" });
    setEditingMedicine(null);
    setShowForm(true);
  };
  
  const handleDelete = async (id) => {
    if (!window.confirm("Are you sure you want to delete this medicine?")) return;

    try {
      const response = await axios.delete(`${API_BASE_URL}/api/medicines/${id}`);

      if (response.status === 200) {
        toast.success("Medicine deleted successfully!");
        window.location.reload();
      } else {
        toast.error("Failed to delete.");
      }
    } catch (error) {
      console.error("Delete Error:", error);
      toast.error("Error deleting medicine.");
    }
  };

  const totalPages = Math.ceil(filteredMedicines.length / itemsPerPage);
  const paginatedMedicines = filteredMedicines.slice(
    (currentPage - 1) * itemsPerPage,
    currentPage * itemsPerPage
  );

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
     {/* Header & Search */}
     <div className="flex flex-col sm:flex-row justify-between items-center mb-6 gap-3">
        <h2 className="text-2xl font-bold text-gray-800">Admin Panel</h2>
        <div className="flex gap-4">
          <button
            onClick={() => navigate('/payments')}
            className="bg-blue-600 text-white px-4 py-2 rounded-lg hover:bg-blue-700"
          >
            View Payments
          </button>

          <button
            onClick={() => navigate('/')}
            className="bg-gray-600 text-white px-4 py-2 rounded-lg hover:bg-gray-700"
          >
            Back to Home
          </button>
        </div>
        <div className="flex flex-col sm:flex-row items-center gap-4 w-full sm:w-auto">
          <div className="relative w-full sm:w-64">
            <input
              type="text"
              placeholder="Search..."
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              className="border p-2 pl-8 rounded-md w-full"
            />
            <Search className="absolute left-2 top-2.5 text-gray-400 h-5 w-5" />
          </div>
          <button
            onClick={handleAddMedicine}
            className="bg-blue-600 text-white px-4 py-2 rounded-lg hover:bg-blue-700 flex items-center gap-2 w-full sm:w-auto justify-center"
          >
            <Plus className="h-5 w-5" /> Add Medicine
          </button>
        </div>
      </div>

      {/* Table */}
      <div className="bg-white rounded-lg shadow overflow-hidden">
        <div className="overflow-x-auto">
          <table className="min-w-full text-sm">
            <thead className="bg-gray-50">
              <tr>
                {["Name", "Price", "Expiry", "Stock", "Category", "Actions"].map((head) => (
                  <th key={head} className="px-4 py-3 text-left font-medium text-gray-500">
                    {head}
                  </th>
                ))}
              </tr>
            </thead>
            <tbody>
              {paginatedMedicines.map((medicine) => (
                <tr key={medicine._id} className="hover:bg-gray-50">
                  <td className="px-4 py-4">{medicine.name}</td>
                  <td className="px-4 py-4">₹{medicine.price}</td>
                  <td className="px-4 py-4">{medicine.exp}</td>
                  <td className="px-4 py-4">{medicine.stock}</td>
                  <td className="px-4 py-4">{medicine.category}</td>
                  <td className="px-4 py-4 flex gap-2">
                    <button onClick={() => handleEdit(medicine)} className="text-blue-600">
                      <Edit className="h-5 w-5" />
                    </button>
                    <button onClick={() => handleDelete(medicine._id)} className="text-red-600">
                      <Trash className="h-5 w-5" />
                    </button>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>

        {/* Pagination */}
        <div className="flex flex-wrap justify-center items-center mt-4 mb-6 gap-2">
          <button
            onClick={() => setCurrentPage((prev) => Math.max(prev - 1, 1))}
            disabled={currentPage === 1}
            className="px-4 py-2 rounded-lg bg-blue-600 text-white hover:bg-blue-700 disabled:bg-gray-300"
          >
            Previous
          </button>
          <span className="px-4 py-2">Page {currentPage} of {totalPages}</span>
          <button
            onClick={() => setCurrentPage((prev) => Math.min(prev + 1, totalPages))}
            disabled={currentPage === totalPages}
            className="px-4 py-2 rounded-lg bg-blue-600 text-white hover:bg-blue-700 disabled:bg-gray-300"
          >
            Next
          </button>
        </div>
      </div>

      {showForm && (
        <div className="bg-white p-6 rounded-lg shadow-md mb-6">
          <h3 className="text-xl font-bold mb-4">{editingMedicine ? 'Edit Medicine' : 'Add Medicine'}</h3>
          <form onSubmit={handleSubmit}>
            <input
              type="text"
              placeholder="Name"
              value={newMedicine.name}
              onChange={(e) => setNewMedicine({ ...newMedicine, name: e.target.value })}
              className="w-full p-2 border rounded-md mb-2"
            />
            <input
              type="number"
              placeholder="Price"
              value={newMedicine.price}
              onChange={(e) => setNewMedicine({ ...newMedicine, price: e.target.value })}
              className="w-full p-2 border rounded-md mb-2"
            />
            <input
              type="text"
              placeholder="Expiry Date"
              value={newMedicine.exp}
              onChange={(e) => setNewMedicine({ ...newMedicine, exp: e.target.value })}
              className="w-full p-2 border rounded-md mb-2"
            />
            <input
              type="number"
              placeholder="Stock"
              value={newMedicine.stock}
              onChange={(e) => setNewMedicine({ ...newMedicine, stock: e.target.value })}
              className="w-full p-2 border rounded-md mb-2"
            />
            <input
              type="text"
              placeholder="Category"
              value={newMedicine.category}
              onChange={(e) => setNewMedicine({ ...newMedicine, category: e.target.value })}
              className="w-full p-2 border rounded-md mb-2"
            />
            <button type="submit" className="bg-green-500 text-white px-4 py-2 rounded-md">
              {editingMedicine ? 'Update Medicine' : 'Add Medicine'}
            </button>
            <button
              type="button"
              onClick={() => setShowForm(false)}
              className="ml-2 bg-gray-500 text-white px-4 py-2 rounded-md"
            >
              Cancel
            </button>
          </form>
        </div>
      )}
    </div>
  );
};

export default AdminPanel;
