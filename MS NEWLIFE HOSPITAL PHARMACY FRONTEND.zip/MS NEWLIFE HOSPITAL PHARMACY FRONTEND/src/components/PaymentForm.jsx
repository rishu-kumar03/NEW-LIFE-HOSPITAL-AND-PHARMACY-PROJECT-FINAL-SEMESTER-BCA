import { useState } from 'react';
import { X, Upload } from 'lucide-react';
import axios from 'axios';
const API_BASE_URL = import.meta.env.VITE_API_BASE_URL;
const PaymentForm = ({ total, cartItems, onClose }) => {
  const [formData, setFormData] = useState({
    name: '',
    address: '',
    phone: '',
    paymentProof: null
  });

  const handleSubmit = async (e) => {
    e.preventDefault();

    const formDataToSend = new FormData();
    formDataToSend.append('name', formData.name);
    formDataToSend.append('address', formData.address);
    formDataToSend.append('phone', formData.phone);
    formDataToSend.append('amount', total);
    formDataToSend.append('paymentProof', formData.paymentProof);

    // Add Cart Details to FormData
    formDataToSend.append('cartItems', JSON.stringify(cartItems));

    try {
      const response = await axios.post(
        `${API_BASE_URL}/api/payments/create`, // Replace with your actual API URL
        formDataToSend
      );

      if (response.status === 201) {
        alert('Payment submitted successfully!');
        onClose(); // Close the modal
      } else {
        alert('Failed to submit payment.');
      }
    } catch (error) {
      console.error('Payment Error:', error);
      alert('Error submitting payment. Please try again.');
    }
  };

  const handleFileChange = (e) => {
    const file = e.target.files[0];
    if (file) {
      setFormData(prev => ({ ...prev, paymentProof: file }));
    }
  };

  return (
    <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50 p-4">
      <div className="bg-white rounded-lg p-6 w-full max-w-md max-h-[90vh] overflow-y-auto shadow-lg">
        {/* Header */}
        <div className="flex justify-between items-center mb-4">
          <h2 className="text-xl font-semibold">Payment Details</h2>
          <button onClick={onClose} className="text-gray-500 hover:text-gray-700">
            <X className="h-6 w-6" />
          </button>
        </div>

        {/* Form */}
        <form onSubmit={handleSubmit} className="space-y-4">
          {/* Name */}
          <div>
            <label className="block text-sm font-medium text-gray-700 mb-1">
              Full Name
            </label>
            <input
              type="text"
              required
              className="w-full px-3 py-2 border rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500"
              value={formData.name}
              onChange={(e) => setFormData(prev => ({ ...prev, name: e.target.value }))}
            />
          </div>

          {/* Address */}
          <div>
            <label className="block text-sm font-medium text-gray-700 mb-1">
              Delivery Address
            </label>
            <textarea
              required
              className="w-full px-3 py-2 border rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500"
              rows="3"
              value={formData.address}
              onChange={(e) => setFormData(prev => ({ ...prev, address: e.target.value }))}
            />
          </div>

          {/* Phone */}
          <div>
            <label className="block text-sm font-medium text-gray-700 mb-1">
              Phone Number
            </label>
            <input
              type="tel"
              required
              className="w-full px-3 py-2 border rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500"
              value={formData.phone}
              onChange={(e) => setFormData(prev => ({ ...prev, phone: e.target.value }))}
            />
          </div>

          {/* QR Code */}
          <div>
            <p className="text-sm font-medium text-gray-700 mb-2">
              Scan QR Code to Pay
            </p>
            <div className="bg-gray-100 p-4 rounded-lg text-center">
              <div className="w-48 h-48 mx-auto bg-white border-2 border-dashed border-gray-300 rounded-lg flex items-center justify-center mb-2">
                <img src="/images/hospitalpharmacyqr.png" alt="PhonePe QR Code" className="w-full h-full object-cover" />
              </div>
            </div>
          </div>

          {/* Payment Proof Upload */}
          <div>
            <label className="block text-sm font-medium text-gray-700 mb-1">
              Upload Payment Proof
            </label>
            <div className="border-2 border-dashed border-gray-300 rounded-lg p-4 text-center">
              <input
                type="file"
                accept="image/*"
                required
                className="hidden"
                id="payment-proof"
                onChange={handleFileChange}
              />
              <label
                htmlFor="payment-proof"
                className="cursor-pointer flex flex-col items-center"
              >
                <Upload className="h-8 w-8 text-gray-400 mb-2" />
                <span className="text-sm text-gray-500">
                  {formData.paymentProof
                    ? formData.paymentProof.name
                    : 'Click to upload payment screenshot'}
                </span>
              </label>
            </div>
          </div>

          {/* Submit Button */}
          <button
            type="submit"
            className="w-full bg-blue-600 text-white py-2 rounded-lg hover:bg-blue-700 transition-colors"
          >
            Complete Payment
          </button>
        </form>
      </div>
    </div>
  );
};

export default PaymentForm;
