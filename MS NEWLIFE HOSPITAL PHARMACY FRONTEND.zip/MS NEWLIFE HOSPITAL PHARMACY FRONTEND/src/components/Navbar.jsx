import { ShoppingBag, Pill, X } from "lucide-react";
import {  NavLink, useNavigate } from 'react-router-dom';
import { AuthContext } from '../context/AuthContext';
import { useContext, useState } from "react";
import Login from "./Login"; // Import your existing Login component

const Navbar = ({ cartCount, onCartClick }) => {
  const { auth, logout } = useContext(AuthContext) || {};
  const [showLoginSidebar, setShowLoginSidebar] = useState(false);

  const navigate = useNavigate(); // Initialize useNavigate

  const handleLogout = () => {
    logout();
    navigate('/'); // Redirect to "/" after logout
  };


  return (
    <>
      <nav className="bg-white shadow-md sticky top-0 mb-5 z-40 w-full">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex justify-between items-center h-16">
            {/* Logo Section */}
            <div className="flex items-center space-x-2">
              <Pill className="h-6 w-6 sm:h-8 sm:w-8 text-blue-600" />
              <span className="text-lg sm:text-xl md:text-2xl font-bold text-gray-800">Pharmacy</span>
            </div>

            {/* Cart Button */}
            <button
              onClick={onCartClick}
              className="relative flex items-center p-2 rounded-md hover:bg-gray-100 transition-colors"
            >
              <ShoppingBag className="h-5 w-5 sm:h-6 sm:w-6 text-gray-600" />
              {cartCount > 0 && (
                <span className="absolute -top-2 -right-2 bg-red-500 text-white rounded-full w-5 h-5 flex items-center justify-center text-xs sm:text-sm">
                  {cartCount}
                </span>
              )}
            </button>

            {/* Admin Login Button */}
            {!auth?.token && (
              <button
                onClick={() => setShowLoginSidebar(true)}
                className="bg-blue-600 text-white rounded-md px-4 py-2 hover:bg-blue-700 transition duration-300 ease-in-out"
              >
                Admin Login
              </button>
            )}

            {auth?.token && (
              <button
              onClick={handleLogout} 
                className="bg-red-600 text-white rounded-md px-4 py-2 hover:bg-red-700 transition duration-300 ease-in-out"
              >
                Logout
              </button>
            )}
          </div>
        </div>
      </nav>

      {/* Sidebar Login (Wider Sidebar) */}
      <div
        className={`fixed top-0 right-0 h-full w-full max-w-lg bg-white shadow-2xl transform ${
          showLoginSidebar ? "translate-x-0" : "translate-x-full"
        } transition-transform duration-300 ease-in-out z-50`}
      >
        <div className="p-6 flex justify-between items-center border-b border-gray-200">
          <h3 className="text-2xl font-bold text-blue-600">Admin Login</h3>
          <button
            onClick={() => setShowLoginSidebar(false)}
            className="text-gray-500 hover:text-red-500"
          >
            <X className="h-6 w-6" />
          </button>
        </div>

        {/* Updated Login Form with Improved Design */}
        <div className="p-6">
        <Login onLoginSuccess={() => setShowLoginSidebar(false)} />
        </div>
      </div>

      {/* Background Overlay when Sidebar is Open */}
      {showLoginSidebar && (
        <div
          className="fixed inset-0 bg-black bg-opacity-50 z-40"
          onClick={() => setShowLoginSidebar(false)}
        ></div>
      )}
    </>
  );
};

export default Navbar;
