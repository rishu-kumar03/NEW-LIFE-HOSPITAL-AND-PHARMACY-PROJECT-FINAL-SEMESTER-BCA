import { useContext, useState, useEffect } from 'react';
import { BrowserRouter as Router, Route, Routes, useNavigate } from 'react-router-dom';
import Navbar from './components/Navbar';
import MedicineList from './components/MedicineList';
import Cart from './components/Cart';
import PaymentForm from './components/PaymentForm';
import AdminPanel from './components/AdminPanel';
import Login from './components/Login';
import { AuthContext } from './context/AuthContext';
import PaymentList from './components/PaymentList';

const API_BASE_URL = import.meta.env.VITE_API_BASE_URL;

function App() {
  const { auth, user } = useContext(AuthContext) || {};
  const [medicines, setMedicines] = useState([]);
  const [cartItems, setCartItems] = useState([]);
  const [showPayment, setShowPayment] = useState(false);
  const [isCartOpen, setIsCartOpen] = useState(false);
  const [showLoginSidebar, setShowLoginSidebar] = useState(false);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(null);
  const navigate = useNavigate();

  // Fetch medicines from backend
  useEffect(() => {
    const fetchMedicines = async () => {
      try {
        const response = await fetch(`${API_BASE_URL}/api/medicines`);
        if (!response.ok) {
          throw new Error('Failed to fetch medicines');
        }
        const data = await response.json();

        // Normalize MongoDB's _id for consistency
        const normalizedData = data.map((item) => ({
          ...item,
          id: item._id // Map '_id' to 'id' for easier handling in state management
        }));

        setMedicines(normalizedData);
      } catch (err) {
        setError(err.message);
      } finally {
        setLoading(false);
      }
    };

    fetchMedicines();
  }, []);

  // Auto-redirect to Admin Panel if logged in as admin
  useEffect(() => {
    if (auth && user?.role === 'admin') {
      navigate('/admin');
    }
  }, [auth, user, navigate]);

  const addToCart = (medicine) => {
    setCartItems((prev) => {
      const existingItem = prev.find((item) => item.id === medicine.id);
      if (existingItem) {
        return prev.map((item) =>
          item.id === medicine.id
            ? { ...item, quantity: item.quantity + 1 }
            : item
        );
      }
      return [...prev, { ...medicine, quantity: 1 }];
    });
  };

  const removeFromCart = (medicineId) => {
    setCartItems((prev) => prev.filter((item) => item.id !== medicineId));
  };

  const updateQuantity = (medicineId, change) => {
    setCartItems((prev) =>
      prev
        .map((item) =>
          item.id === medicineId
            ? { ...item, quantity: Math.max(1, item.quantity + change) }
            : item
        )
        .filter(Boolean)
    );
  };

  const total = cartItems.reduce(
    (sum, item) => sum + item.price * item.quantity,
    0
  );

  return (
    <div className="min-h-screen bg-gray-50">
      <Navbar
        cartCount={cartItems.reduce((sum, item) => sum + item.quantity, 0)}
        onCartClick={() => setIsCartOpen(true)}
        onAdminLoginClick={() => setShowLoginSidebar(true)}
      />

      <Routes>
        <Route
          path="/admin"
          element={
            auth && auth.isAdmin === true ? (
              <AdminPanel medicines={medicines} />
            ) : (
              <Login onLoginSuccess={() => navigate('/admin')} />
            )
          }
        />
        <Route
          path="/payments"
          element={
            auth && auth.isAdmin ? <PaymentList /> : <Login />
          }
        />

        <Route
          path="/"
          element={
            <div className="container mx-auto px-4 py-8">
              {loading ? (
                <p className="text-center text-gray-500">Loading medicines...</p>
              ) : error ? (
                <p className="text-center text-red-500">{error}</p>
              ) : (
                <MedicineList medicines={medicines} addToCart={addToCart} />
              )}

              <Cart
                items={cartItems}
                removeFromCart={removeFromCart}
                onProceedToPayment={() => setShowPayment(true)}
                isOpen={isCartOpen}
                onClose={() => setIsCartOpen(false)}
                updateQuantity={updateQuantity}
              />

              {showPayment && (
                <PaymentForm
                  total={total}
                  cartItems={cartItems}
                  onClose={() => setShowPayment(false)}
                />
              )}
            </div>
          }
        />
      </Routes>
    </div>
  );
}

export default App;
